from numpy.core.arrayprint import format_float_scientific
from numpy.core.fromnumeric import size
from numpy.core.numeric import True_
import pandas as pd
import tkinter as tk
from tkinter import *

df = pd.read_csv('estoque.csv', sep=';',encoding='cp1252',usecols=[1,2,7,9,11,14,55,56,57])

#loc = df['SituacaoDescricao'].groupby(['Esc01Descricao'])
exp_pa  = df.loc[(df['SituacaoDescricao'] == 'Aguardando coleta')]
exp_pa_df = exp_pa.reset_index(drop=True)
todo_exp_rom_df = exp_pa_df['Romaneio'].value_counts()
soma = 0
todo = len(todo_exp_rom_df)
print(todo)
for i in range(len(todo_exp_rom_df)):
    print (i)

