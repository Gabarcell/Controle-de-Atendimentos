from numpy.core.arrayprint import format_float_scientific
from numpy.core.fromnumeric import size
from numpy.core.numeric import True_
import numpy as np
import pandas as pd
import tkinter as tk
from tkinter import *

df_estoque = pd.read_csv('estoque.csv', sep=';',encoding='cp1252',usecols=[1,2,7,9,11,14,50,55,56,57])
df = pd.read_csv('atendimentos.csv', sep=';',encoding='cp1252',usecols=[8,12,15,16,20,29,30,34,35,39,41,61,63,65])
null = "NaN"
os_estoque = df_estoque['OsNumero'].dropna().astype(np.int64)
os= df['NUMERO O.S. CS1'].dropna().astype(np.int64)

for x in os:    
    if x == os_estoque:
        print(os_estoque[x])
