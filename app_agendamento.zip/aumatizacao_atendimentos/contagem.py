import pandas as pd


df = pd.read_csv('atendimentos.csv', sep=';',encoding='cp1252',usecols=[3,4,5,7,8,12,15,16,20,26,29,30,34,35,38,39,41,44,46,49,50,51,52,54,58,59,60,61,62,63,64,65])

total_atendimento = df.loc[(df[' TÉCNICO'] == 'JOAO FELIPE PEDROSO LOPES')]
print(total_atendimento[' CIDADE'].value_counts())
print(total_atendimento[' SERVIÇO'].value_counts())
print(total_atendimento[' STATUS'].value_counts())
print(len(total_atendimento[' STATUS']))